// Basic client-side behavior and validation for the demo login page.
// NOTE: This is a mock — do NOT send real credentials to any endpoint here.

document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('loginForm');
  const email = document.getElementById('email');
  const password = document.getElementById('password');

  form.addEventListener('submit', (ev) => {
    ev.preventDefault();

    // Simple validation
    const eVal = email.value.trim();
    const pVal = password.value;

    if (!eVal) {
      showMessage('Please enter your email or phone number.', email);
      return;
    }
    if (!pVal || pVal.length < 6) {
      showMessage('Please enter your password (6+ characters).', password);
      return;
    }

    // Demo behavior: show a success toast and log to console
    showMessage('Login submitted (demo).', null, 'success');
    console.log('Demo login attempt:', { email: eVal, password: '[REDACTED]' });

    // Simulate a network delay then clear the form (for the demo only)
    setTimeout(() => {
      form.reset();
    }, 800);
  });

  document.getElementById('createAccount').addEventListener('click', () => {
    showMessage('Create account clicked (demo).', null);
  });

  function showMessage(text, focusEl = null, level = 'error') {
    // simple ephemeral message at top of form
    let existing = document.getElementById('demoMessage');
    if (existing) existing.remove();

    const div = document.createElement('div');
    div.id = 'demoMessage';
    div.textContent = text;
    div.setAttribute('role', 'status');
    div.style.padding = '10px';
    div.style.marginBottom = '8px';
    div.style.borderRadius = '6px';
    div.style.fontSize = '14px';
    div.style.color = level === 'success' ? '#0f5132' : '#842029';
    div.style.background = level === 'success' ? '#d1e7dd' : '#f8d7da';
    const formEl = document.querySelector('.login-form');
    formEl.insertBefore(div, formEl.firstChild);

    if (focusEl) focusEl.focus();

    setTimeout(() => {
      div.remove();
    }, 3500);
  }
});